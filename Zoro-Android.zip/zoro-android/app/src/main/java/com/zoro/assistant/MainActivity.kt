package com.zoro.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

// Free, keyless AI endpoint (OpenAI-compatible). Change this if you want another provider.
private const val AI_URL = "https://text.pollinations.ai/openai"

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val ui = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pending: (() -> Unit)? = null
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var fileCb: ValueCallback<Array<Uri>>? = null

    private fun js(code: String) { ui.post { web.evaluateJavascript(code, null) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#030a05"))
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.allowFileAccess = false

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try { startActivityForResult(p.createIntent(), 7); true } catch (e: Exception) { fileCb = null; false }
            }
        }
        web.addJavascriptInterface(Bridge(), "AndroidBridge")

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) { js("__nTts('start',$id)") }
                    override fun onDone(id: String?) { js("__nTts('end',$id)") }
                    override fun onError(id: String?) { js("__nTts('end',$id)") }
                    override fun onError(id: String?, code: Int) { js("__nTts('end',$id)") }
                })
                ttsReady = true
                pending?.invoke()
                pending = null
            }
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        }
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 7) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCb = null
        } else super.onActivityResult(requestCode, resultCode, data)
    }

    private fun startListen(lang: String) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            js("__nRec('error','not-allowed');__nRec('end')")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            js("__nRec('error','service-not-allowed');__nRec('end')")
            return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { listening = true; js("__nRec('start')") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
            override fun onResults(res: Bundle?) {
                listening = false
                val t = res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t != null) js("__nRec('result',${JSONObject.quote(t)})")
                js("__nRec('end')")
            }
            override fun onError(e: Int) {
                listening = false
                val c = when (e) { 6, 7 -> "no-speech"; 9 -> "not-allowed"; 1, 2, 4 -> "network"; else -> "aborted" }
                js("__nRec('error','$c');__nRec('end')")
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
        r.startListening(i)
    }

    inner class Bridge {
        @JavascriptInterface fun listen(lang: String) { ui.post { startListen(lang) } }

        @JavascriptInterface fun stopListen() {
            ui.post {
                recognizer?.cancel()
                if (listening) { listening = false; js("__nRec('end')") }
            }
        }

        @JavascriptInterface fun speak(id: Int, text: String, lang: String, rate: Double, pitch: Double) {
            ui.post {
                val go: () -> Unit = {
                    tts?.let { t ->
                        t.language = Locale.forLanguageTag(lang)
                        t.setSpeechRate(rate.toFloat().coerceIn(0.5f, 2f))
                        t.setPitch(pitch.toFloat().coerceIn(0.5f, 1.5f))
                        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, id.toString())
                    }
                }
                if (ttsReady) go() else pending = go
            }
        }

        @JavascriptInterface fun stop() { ui.post { tts?.stop() } }

        @JavascriptInterface fun ask(id: Int, prompt: String) {
            Thread {
                try {
                    val body = JSONObject().put("model", "openai").put(
                        "messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt))
                    )
                    val c = URL(AI_URL).openConnection() as HttpURLConnection
                    c.requestMethod = "POST"
                    c.connectTimeout = 15000
                    c.readTimeout = 60000
                    c.doOutput = true
                    c.setRequestProperty("Content-Type", "application/json")
                    c.outputStream.use { it.write(body.toString().toByteArray()) }
                    val code = c.responseCode
                    if (code !in 200..299) throw Exception("HTTP $code")
                    val txt = c.inputStream.bufferedReader().readText()
                    val out = JSONObject(txt).getJSONArray("choices").getJSONObject(0)
                        .getJSONObject("message").getString("content")
                    js("__nAsk($id,true,${JSONObject.quote(out)})")
                } catch (e: Exception) {
                    js("__nAsk($id,false,${JSONObject.quote(e.message ?: "error")})")
                }
            }.start()
        }
    }

    override fun onDestroy() {
        tts?.shutdown()
        recognizer?.destroy()
        web.destroy()
        super.onDestroy()
    }
}
